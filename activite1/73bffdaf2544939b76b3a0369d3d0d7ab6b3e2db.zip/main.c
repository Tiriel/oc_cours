//
//  main.c
//  Tutoriel_C
//
//  Created by Presley Nkambou on 17-01-17.
//  Copyright © 2017 Presley Nkambou. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

int menu()
{
    int choix = 0;
    
    while (choix < 1 || choix > 3)
    {
        printf("Menu :\n");
        printf("1 : NIVEAU 1\n");
        printf("2 : NIVEAU 2\n");
        printf("3 : NIVEAU 3\n");
        printf("Votre choix ? ");
        scanf("%d", &choix);
    }
    
    return choix;
}

int main()
{
    srand(time(NULL));
    int MAX = 0, MIN = 0;
    
    int recommencer = 0;
    
    do {
        switch (menu()){
            case 1 :
                MAX = 100, MIN = 1;
                break;
            case 2 :
                MAX = 1000, MIN = 1;
                break;
            case 3 :
                MAX = 10000, MIN = 1;
                break;
        }
        
        unsigned int nombreMystere = (rand() % (MAX - MIN + 1)) + MIN;
        int nombreEssayer = 0;
        unsigned int compteur = 0;
        
        while(nombreEssayer != nombreMystere){
            compteur++;
            printf("Quel est le nombre ? ");
            scanf("%d", &nombreEssayer);
            if (nombreEssayer < nombreMystere){
                printf("C'est plus !\n\n");
            } else if (nombreEssayer > nombreMystere){
                printf("C'est moins !\n\n");
            } else {
            printf("Bravo, vous avez trouve le nombre mystere en %u coups !!!\n\n", compteur);
            }
        }
        printf("Voulez-vous recommencer une autre partie (1 = oui, 0 = non) ? ");
        scanf("%d", &recommencer);
        printf("\n\n");
    } while(recommencer);
    
    return 0;
}
