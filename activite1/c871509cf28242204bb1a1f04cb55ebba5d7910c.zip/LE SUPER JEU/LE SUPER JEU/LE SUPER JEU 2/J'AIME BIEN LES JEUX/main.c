#include <stdio.h>
#include <stdlib.h>
#include <time.h>



int main(int argc, char *argv[])
{

int ModeDeJeu = 0, Difficulte = 100, TentativeNombre = 0 , nombreMystere = 0, compteur = 0, NombreChoisis = 0, Relancer = 0;


printf("Bievenue dans le plus ou moins ! Quel mode de jeu souhaitez vous lancer ? \n 1 joueurs ? ou 2 Joueurs\n");
scanf("%d",&ModeDeJeu);

if (ModeDeJeu == 1)
{
	printf("Combien de nombre voulez vous ? Entrez un chiffre \n");
	scanf("%d", &Difficulte);
	const int MAX = Difficulte, MIN = 1;
	srand(time(NULL));
	nombreMystere = (rand() % (MAX - MIN + 1)) + MIN;
	do {
	printf("Quel est le nombre , %d tentatives\n", compteur);
	scanf("%d", &TentativeNombre);
	compteur++;
	if(nombreMystere > TentativeNombre)
	{
		printf("C'est plus\n");
	}
	else if(nombreMystere < TentativeNombre)
	{
		printf("C'est moins\n");
	}
	else if(nombreMystere == TentativeNombre)
	{printf("C'est juste\n Voulez vous relancer une partie un joueur ?\n 1- Oui \n 2- Non\n");
	compteur = 0;
	srand(time(NULL));
	nombreMystere = (rand() % (MAX - MIN + 1)) + MIN;
	scanf("%d", &Relancer);
	}

	}
while (TentativeNombre != nombreMystere || Relancer != 2);
}
else if (ModeDeJeu == 2)
{
printf("Choisissez un nombre !");
scanf("%d", &NombreChoisis);
	do {
	printf("Quel est le nombre , %d tentatives\n", compteur);
	scanf("%d", &TentativeNombre);
	compteur++;
	if(NombreChoisis > TentativeNombre)
	{
		printf("C'est plus\n");
	}
	else if(NombreChoisis < TentativeNombre)
	{
		printf("C'est moins\n");
	}
	else if(NombreChoisis == TentativeNombre)
	{
	printf("C'est juste\n");
	}

}
while (TentativeNombre != NombreChoisis);
}
return 0;
}


